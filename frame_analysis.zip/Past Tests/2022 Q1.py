import numpy as np
from frame_analysis import FrameAnalysis

def main():
    """
    Example usage of the Frame Analysis tool.
    Configure your problem here and run the analysis.
    """
    analyzer = FrameAnalysis()

    E = 200e9
    I = 5e-6
    A = 2e-4
    
    config = {
        # Define nodes with coordinates and boundary conditions
        'nodes': {

            1: {'coords': np.array([0, 0]),   'type': 'fixed'},
            2: {'coords': np.array([4, 3]),   'type': 'free'},
            3: {'coords': np.array([4, 0]),   'type': 'roller_x'},
        },

        # Element properties - reference nodes by ID
        'elements': [
            {  # Element 1: connects node 1 to node 2
                'start_node': 1,
                'end_node': 3,
                'length': 4,                    # m
                'angle': 0,                     # degrees

                'assembly_matrix': np.array([[0, 0, 0, 0, 0, 0],
                                             [0, 0, 0, 0, 0, 0],
                                             [0, 0, 0, 0, 0, 0],
                                             [0, 0, 0, 1, 0, 0],
                                             [0, 0, 0, 0, 0, 1]]),

                'second_moment_of_area': I,  # m^4
                'area': A,                   # m^2
                'youngs_modulus': E,        # Pa
            },
            {  # Element 2: connects node 1 to node 3
                'start_node': 1,
                'end_node': 2,
                'length': 5,                    # m
                'angle': 36.87,                 # degrees
                'assembly_matrix': np.array([[0, 0, 0, 1, 0, 0],
                                             [0, 0, 0, 0, 1, 0],   
                                             [0, 0, 0, 0, 0, 1],
                                             [0, 0, 0, 0, 0, 0],
                                             [0, 0, 0, 0, 0, 0]]),

                'second_moment_of_area': I,  # m^4
                'area': A,                   # m^2
                'youngs_modulus': E,        # Pa

            },
            {  # Element 3: connects node 2 to node 3
                'start_node': 2,
                'end_node': 3,
                'length': 3,                    # m
                'angle': 270,                    # degrees
                'assembly_matrix': np.array([[1, 0, 0, 0, 0, 0],
                                             [0, 1, 0, 0, 0, 0],   
                                             [0, 0, 1, 0, 0, 0],
                                             [0, 0, 0, 1, 0, 0],
                                             [0, 0, 0, 0, 0, 1]]),
                                             

                'second_moment_of_area': I,  # m^4
                'area': A,                   # m^2
                'youngs_modulus': E,        # Pa
            }
        ],

        # Distributed loads (UDL, LVL_peakXL, LVL_peakXZERO, PDL)
        'loads': [
            {'type': 'UDL', 'element': 1, 'magnitude': -25000, 'direction': 'vertical'},  # N/m on element 1
            # {'type': 'LVL_peakXZERO', 'element': 1, 'magnitude': 10000},  # N/m peak at x=0 on element 1
            # {'type': 'LVL_peakXL', 'element': 1, 'magnitude': 10000}  # N/m peak at x=L
            # {'type': 'PDL', 'element': 2, 'magnitude': 20000, 'direction': 'vertical', 'a': 1.5},  # N on element 2
            # {'type': 'DAL', 'element': 2, 'magnitude': 15000},  # N on element 2
            # {'type': 'CAL', 'element': 2, 'magnitude': 10000, 'a': 1.5},  # N on element 2
        ],
        
        # Normal nodal forces - adjust size based on your DOFs
        'normal_forces': [20000, 40000, 0, 0, 0],  # [N, N⋅m] corresponding to DOFs
        
        # Display options
        'display_magnitude': 100,        # Magnification factor for deflection plot
        'show_matrices': True,           # True for vertical matrix display, False for standard
        'show_deflection_labels': True   # True to show deflection values on plot
    }

    results = analyzer.run_analysis(config)

if __name__ == "__main__":
    main()